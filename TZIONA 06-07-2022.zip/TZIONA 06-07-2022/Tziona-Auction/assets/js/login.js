//login
const container = document.querySelector(".container"),
  pwShowHide = document.querySelectorAll(".showHidePw"),
  pwFields = document.querySelectorAll(".password"),
  signUp = document.querySelector(".signup-link"),
  login = document.querySelector(".login-link");

//   js code to show/hide password and change icon
pwShowHide.forEach((eyeIcon) => {
  eyeIcon.addEventListener("click", () => {
    pwFields.forEach((pwField) => {
      if (pwField.type === "password") {
        pwField.type = "text";

        pwShowHide.forEach((icon) => {
          icon.classList.replace("uil-eye-slash", "uil-eye");
        });
      } else {
        pwField.type = "password";

        pwShowHide.forEach((icon) => {
          icon.classList.replace("uil-eye", "uil-eye-slash");
        });
      }
    });
  });
});

// js code to appear signup and login form
signUp.addEventListener("click", () => {
  container.classList.add("active");
});
login.addEventListener("click", () => {
  container.classList.remove("active");
});

function validateUsername() {
  let usernameError = document.getElementById("username-validation");
  let user = document.getElementById("username").value;

  if (user.length == 0) {
    usernameError.innerHTML = "Name is required";
    usernameError.style.color = "#FF0000";
    return false;
  }
  if (!user.match(/^[A-Za-z0-9]*$/)) {
    alert("Username consist of letters and numbers only");
    usernameError.innerHTML = "Name is invalid";
    usernameError.style.color = "#FF0000";
    return false;
  }
  usernameError.innerHTML = "Name is valid";
  usernameError.style.color = "#1dcd59";
  return true;
}

function validate() {
  var confirmpassError = document.getElementById("ConfirmPass-validation");
  var password = document.getElementById("pass");
  var confirmpass3 = document.getElementById("passconfirm");

  if (password.value.length >= 8) {
    confirmpassError.innerHTML = "you have to enter at least 8 digit";
    confirmpassError.style.color = "#FF0000";
  } else {
    confirmpassError.innerHTML = "you have to enter at least 8 digit";
    confirmpassError.style.color = "#FF0000";
    return;
  }

  if (password.value == confirmpass3.value) {
    confirmpassError.innerHTML = "Password Match!";
    confirmpassError.style.color = "#1dcd59";
    return true;
  } else {
    confirmpassError.innerHTML = "Password don't match";
    confirmpassError.style.color = "#FF0000";

  }

  if(password.value.length == 0){
  confirmpassError.innerHTML = "Yowza, password is required silly.";
  confirmpassError.style.color = "#FF0000";
    }
}


function validateEmail() {
  let emailerror = document.getElementById("email-validation");
  let Email = document.getElementById("contact-email").value;

  if (Email.length == 0) {
    emailerror.innerHTML = "Email is required";
    emailerror.style.color = "#FF0000";
    return false;
  }
  if (!Email.match(/^[A-Za-z\._\-[0-9]*[@][A-Za-z]*[\.][a-z]{2,4}$/)) {
    emailerror.innerHTML = "Email invalid";
    emailerror.style.color = "#FF0000";
    return false;
  }
  emailerror.innerHTML = "Email is valid";
  emailerror.style.color = "#1dcd59";
  return true;
}

function validateForm() {
  let submitError = document.getElementById("submit-validation");
  if (!validate() || !validateEmail() || !validateUsername()) {
    submitError.style.display = "block";
    submitError.innerHTML = "Fix the error above.";
    submitError.style.color = "#FF0000";
    setTimeout(function () {
      submitError.style.display = "none";
    }, 3000);
    return false;
  }
  else{
    submitError.innerHTML = "Login success.";
    submitError.style.color = "#1dcd59";
      return true;
  }
}
